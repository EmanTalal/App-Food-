package com.example.appfood;

public interface ChangeNumberitemListener {
    void changed();
}
