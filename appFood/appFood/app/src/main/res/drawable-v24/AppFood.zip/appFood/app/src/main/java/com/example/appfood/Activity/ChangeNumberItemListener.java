package com.example.appfood.Activity;

public interface ChangeNumberItemListener {
    void changed();
}
